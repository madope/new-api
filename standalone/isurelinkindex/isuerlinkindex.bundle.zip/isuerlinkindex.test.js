import assert from 'node:assert/strict'
import { describe, test } from 'node:test'
import { existsSync, readFileSync } from 'node:fs'
import { resolve } from 'node:path'

const html = readFileSync(
  resolve('standalone/isurelinkindex/isuerlinkindex.html'),
  'utf8'
)
const jsPath = resolve('standalone/isurelinkindex/isuerlinkindex.local.js')
const js = existsSync(jsPath) ? readFileSync(jsPath, 'utf8') : ''

describe('ISURELINK local standalone page', () => {
  test('uses only local assets', () => {
    assert.doesNotMatch(html, /https:\/\/cdn\.tailwindcss\.com/)
    assert.doesNotMatch(html, /https:\/\/fonts\.googleapis\.com/)
    assert.match(html, /<link[^>]+href="\.\/isuerlinkindex\.local\.css"/)
    assert.match(html, /<script[^>]+src="\.\/isuerlinkindex\.local\.js"/)
  })

  test('supports multilingual content and theme sync', () => {
    const source = html + js
    assert.match(source, /const translations = \{/)
    assert.match(source, /zh:/)
    assert.match(source, /en:/)
    assert.match(source, /fr:/)
    assert.match(source, /ja:/)
    assert.match(source, /ru:/)
    assert.match(source, /vi:/)
    assert.match(source, /themeMode/)
    assert.match(source, /window\.addEventListener\('message'/)
  })

  test('login button is wired to a real target path', () => {
    const source = html + js
    assert.match(html, /id="cta-login-button"/)
    assert.match(source, /loginPath/)
    assert.doesNotMatch(html, /href="#"/)
  })
})

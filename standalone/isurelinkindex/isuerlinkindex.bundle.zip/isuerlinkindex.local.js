(function () {
  const translations = {
    zh: {
      title: 'ISURELINK - 大模型 API 聚合网关',
      heroTitlePrefix: '大模型 API ',
      heroTitleAccent: '聚合网关',
      featureOne: '多模型统一接入',
      featureTwo: '稳定高效',
      featureThree: '安全可控',
      loginCta: '登录',
    },
    en: {
      title: 'ISURELINK - LLM API Aggregation Gateway',
      heroTitlePrefix: 'LLM API ',
      heroTitleAccent: 'Aggregation Gateway',
      featureOne: 'Unified multi-model access',
      featureTwo: 'Stable and efficient',
      featureThree: 'Secure and controllable',
      loginCta: 'Sign In',
    },
    fr: {
      title: 'ISURELINK - Passerelle API LLM unifiee',
      heroTitlePrefix: 'Passerelle API LLM ',
      heroTitleAccent: 'unifiee',
      featureOne: 'Acces unifie a plusieurs modeles',
      featureTwo: 'Stable et efficace',
      featureThree: 'Securise et maitrisable',
      loginCta: 'Connexion',
    },
    ja: {
      title: 'ISURELINK - LLM API Aggregation Gateway',
      heroTitlePrefix: 'LLM API ',
      heroTitleAccent: 'Aggregation Gateway',
      featureOne: '複数モデルへの統一アクセス',
      featureTwo: '安定して高効率',
      featureThree: '安全で制御しやすい',
      loginCta: 'ログイン',
    },
    ru: {
      title: 'ISURELINK - Shlyuz agregatsii LLM API',
      heroTitlePrefix: 'Shlyuz ',
      heroTitleAccent: 'agregatsii LLM API',
      featureOne: 'Edinyi dostup ko mnogim modelyam',
      featureTwo: 'Stabilno i effektivno',
      featureThree: 'Bezopasno i pod kontrolem',
      loginCta: 'Vhod',
    },
    vi: {
      title: 'ISURELINK - Cong API tong hop LLM',
      heroTitlePrefix: 'Cong API ',
      heroTitleAccent: 'tong hop LLM',
      featureOne: 'Truy cap hop nhat da mo hinh',
      featureTwo: 'On dinh va hieu qua',
      featureThree: 'An toan va de kiem soat',
      loginCta: 'Dang nhap',
    },
  }

  const root = document.documentElement
  const searchParams = new URLSearchParams(window.location.search)
  const nav = document.querySelector('[data-purpose="navigation"]')
  const loginButton = document.getElementById('cta-login-button')
  const heroTitle = document.querySelector('[data-i18n="heroTitle"]')

  function normalizeLang(lang) {
    if (!lang) return 'zh'
    const value = String(lang).toLowerCase()
    if (value.startsWith('en')) return 'en'
    if (value.startsWith('fr')) return 'fr'
    if (value.startsWith('ja')) return 'ja'
    if (value.startsWith('ru')) return 'ru'
    if (value.startsWith('vi')) return 'vi'
    return 'zh'
  }

  function applyLanguage(lang) {
    const localeKey = normalizeLang(lang)
    const locale = translations[localeKey]
    root.lang = localeKey === 'zh' ? 'zh-CN' : localeKey
    document.title = locale.title

    document.querySelectorAll('[data-i18n]').forEach((element) => {
      const key = element.getAttribute('data-i18n')
      if (!key || !locale[key]) return

      if (key === 'heroTitle' && heroTitle) {
        heroTitle.innerHTML =
          locale.heroTitlePrefix +
          '<span class="brand-inline">' +
          locale.heroTitleAccent +
          '</span>'
        return
      }

      element.textContent = locale[key]
    })
  }

  function applyTheme(themeMode) {
    const theme = themeMode === 'dark' ? 'dark' : 'light'
    root.setAttribute('data-theme', theme)
  }

  function normalizeBase(input) {
    if (!input) return ''
    try {
      return new URL(input).origin.replace(/\/+$/, '')
    } catch (error) {
      return ''
    }
  }

  function resolveBase() {
    const explicitBase = searchParams.get('base') || searchParams.get('site') || ''
    const normalized = normalizeBase(explicitBase)
    if (normalized) return normalized

    if (
      window.location.protocol === 'http:' ||
      window.location.protocol === 'https:'
    ) {
      return window.location.origin.replace(/\/+$/, '')
    }

    return ''
  }

  function resolveLoginHref() {
    const base = resolveBase()
    const loginPath = searchParams.get('loginPath') || '/login'
    const normalizedPath = loginPath.startsWith('/') ? loginPath : '/' + loginPath
    const target = base || window.location.origin
    return new URL(normalizedPath, target).toString()
  }

  function applyLoginHref() {
    if (!loginButton) return
    loginButton.href = resolveLoginHref()
  }

  function notifyParentReady() {
    try {
      if (window.parent && window.parent !== window) {
        window.parent.postMessage({ type: 'isurelinkindex-ready' }, '*')
      }
    } catch (error) {
      // Ignore parent messaging failures.
    }
  }

  window.addEventListener('message', function (event) {
    const data = event.data || {}
    if (typeof data.themeMode === 'string') {
      applyTheme(data.themeMode)
    }
    if (typeof data.lang === 'string') {
      applyLanguage(data.lang)
    }
  })

  window.addEventListener('scroll', function () {
    if (!nav) return
    if (window.scrollY > 20) {
      nav.classList.add('is-scrolled')
    } else {
      nav.classList.remove('is-scrolled')
    }
  })

  const requestedTheme = searchParams.get('theme')
  if (requestedTheme === 'dark' || requestedTheme === 'light') {
    applyTheme(requestedTheme)
  } else if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
    applyTheme('dark')
  } else {
    applyTheme('light')
  }

  applyLanguage(searchParams.get('lang') || root.lang)
  applyLoginHref()
  notifyParentReady()
  window.addEventListener('load', notifyParentReady)
})()
